import React, { useState } from "react";
import "./index.css";

const products = [
  {
    id: 1,
    name: "স্যামসাং গ্যালাক্সি S24",
    category: "মোবাইল",
    price: "৳94,999",
    image: "https://via.placeholder.com/300x200?text=Galaxy+S24",
    description: "নতুন প্রজন্মের স্মার্টফোন শক্তিশালী পারফর্মেন্স সহ।"
  },
  {
    id: 2,
    name: "রিয়েলমি Buds T100",
    category: "হেডফোন",
    price: "৳1,999",
    image: "https://via.placeholder.com/300x200?text=Realme+Buds+T100",
    description: "বাজেট ফ্রেন্ডলি এবং ভালো সাউন্ড কোয়ালিটি।"
  },
  {
    id: 3,
    name: "অ্যাপল ওয়াচ সিরিজ 9",
    category: "স্মার্টওয়াচ",
    price: "৳42,500",
    image: "https://via.placeholder.com/300x200?text=Apple+Watch+S9",
    description: "অ্যাপলের নতুন স্মার্টওয়াচ, হেলথ ট্র্যাকিং সহ।"
  }
];

const categories = ["সব", "মোবাইল", "হেডফোন", "স্মার্টওয়াচ"];

export default function GadgetBangla() {
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("সব");
  const [cart, setCart] = useState([]);

  const filteredProducts = products.filter(
    (product) =>
      (selectedCategory === "সব" || product.category === selectedCategory) &&
      product.name.toLowerCase().includes(search.toLowerCase())
  );

  const addToCart = (product) => {
    setCart([...cart, product]);
    alert(`${product.name} কার্টে যোগ হয়েছে!`);
  };

  const totalPrice = cart.reduce((acc, item) => acc + parseInt(item.price.replace(/[^0-9]/g, "")), 0);

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <h1 className="text-4xl font-bold text-center mb-6 text-green-700">গেজেট বাংলা</h1>

      <div className="flex flex-col md:flex-row gap-4 mb-6 justify-between items-center">
        <input
          type="text"
          placeholder="পণ্যের নাম খুঁজুন"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="border p-2 w-full md:w-1/3 rounded"
        />
        <select
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          className="border p-2 rounded"
        >
          {categories.map((cat) => (
            <option key={cat} value={cat}>{cat}</option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {filteredProducts.map((product) => (
          <div key={product.id} className="bg-white rounded-2xl shadow-md overflow-hidden">
            <img src={product.image} alt={product.name} className="w-full h-48 object-cover" />
            <div className="p-4">
              <h2 className="text-xl font-semibold mb-2">{product.name}</h2>
              <p className="text-sm text-gray-600 mb-2">{product.description}</p>
              <p className="text-green-600 font-bold mb-4">{product.price}</p>
              <button
                onClick={() => addToCart(product)}
                className="w-full bg-green-600 text-white py-2 rounded hover:bg-green-700"
              >
                অর্ডার করুন
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-10">
        <h2 className="text-2xl font-bold mb-2">কার্ট ({cart.length})</h2>
        {cart.length === 0 ? (
          <p>আপনার কার্ট খালি</p>
        ) : (
          <div className="space-y-2">
            {cart.map((item, idx) => (
              <div key={idx} className="flex justify-between border-b pb-2">
                <span>{item.name}</span>
                <span>{item.price}</span>
              </div>
            ))}
            <div className="flex justify-between font-bold border-t pt-2">
              <span>মোট</span>
              <span>৳{totalPrice.toLocaleString()}</span>
            </div>
            <button className="mt-4 w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700">
              বিকাশ/নগদ দিয়ে পেমেন্ট করুন
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
