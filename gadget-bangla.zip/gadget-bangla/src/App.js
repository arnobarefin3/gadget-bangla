import React from "react";
import GadgetBangla from "./GadgetBangla";
function App() {
  return <GadgetBangla />;
}
export default App;
